<?php

/* Adding CSS & JS */
function pixelo_basic_enqueue_styles_scripts() {
    wp_register_style( 'styles', get_template_directory_uri() . '/css/styles.css', false, '1.0.2' );
    $dependencies = array( 'styles' );
    wp_enqueue_style( 'styles', get_stylesheet_uri(), $dependencies); 
    add_theme_support( 'post-thumbnails' );
    wp_register_script( 'gsap-tweenmax', get_theme_file_uri('js/TweenMax.min.js'), false, '2.1.3' );
    wp_enqueue_script( 'gsap-tweenmax' );
    wp_enqueue_script( 'accessibility-js', get_template_directory_uri() . '/js/accessibility.js', array(), false );
    wp_enqueue_script( 'pixelo-custom-script', get_stylesheet_directory_uri() . '/js/script.js', array( 'jquery' ) );
}
add_action( 'wp_enqueue_scripts', 'pixelo_basic_enqueue_styles_scripts' );

/**
 * Register and enqueue a custom stylesheet in the WordPress admin.
 */
function pixelo_admin_style() {
    wp_register_style( 'metabox_settings_css', get_template_directory_uri() . '/css/admin-style.css', false, '1.0.0' );
    wp_enqueue_style( 'metabox_settings_css' );
}
add_action( 'admin_enqueue_scripts', 'pixelo_admin_style' );


// Adding Title-Tag
function pixelo_basic_wp_setup() {
    add_theme_support ( 'title-tag' );

 // Post formats
add_theme_support( 'post-formats', array( 'aside', 'audio', 'chat', 'gallery', 'image', 'link', 'quote', 'status', 'video' ) );

    // Define and register starter content to showcase the theme on new sites.
    $starter_content = array(

        // Specify the core-defined pages to create and add custom thumbnails to some of them.
        'posts' => array(
            'home',
            'about',
            'contact',
            'blog',
        ),

        // Default to a static front page and assign the front and posts pages.
        'options' => array(
            'show_on_front'     => 'page',
            'page_on_front'     => '{{home}}',
            'page_for_posts'    => '{{blog}}',
        ),

        // Set up nav menus for each of the two areas registered in the theme.
        'nav_menus' => array(
            // Assign a menu to the "primary" location.
            'primary' => array(
                'name' => __( 'Primary Menu', 'pixelo' ),
                'items' => array(
                    'link_home',
                    'page_about',
                    'page_contact',
                    'page_blog',
                ),
            ),
        ),
    );

    add_theme_support( 'starter-content', $starter_content );
}
add_action ( 'after_setup_theme', 'pixelo_basic_wp_setup' );

// Creating Custom Menu
function pixelo_custom_new_menu() {
    register_nav_menu( 'primary', __( 'Primary Menu', 'pixelo' ) );
}
add_action( 'init', 'pixelo_custom_new_menu' );

// Post Thumbnails
add_theme_support( 'post-thumbnails' );
add_theme_support( 'automatic-feed-links' );


// Support for custom Logo
add_theme_support( 'custom-logo' );
function pixelo_custom_logo_setup() {
    $defaults = array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
        'header-text' => array( 'site-title', 'site-description' ),
    );
    add_theme_support( 'custom-logo', $defaults );
}
add_action( 'after_setup_theme', 'pixelo_custom_logo_setup' );
 
// Customizer Settings
require get_stylesheet_directory() . '/inc/pixelo-customizer.php';
new Pixelo_Customizer();

if ( ! isset( $content_width ) ) {
	$content_width = 600;
}

add_theme_support( 'post-thumbnails', array( 'post' ) ); // Posts only

// Comment Reply Fix
function pixelo_load_script_for_fake_threading() {
  if ( is_singular() ) wp_enqueue_script( 'comment-reply' );
}
add_action( 'wp_enqueue_scripts', 'pixelo_load_script_for_fake_threading' );

require_once get_theme_file_path( '/inc/custom-styles.php' );

/**
 * REQUIRED FILES
 * Include required files.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * REQUIRED FILES
 * Include required files metabox.
 */
require get_template_directory() . '/inc/metabox.php';


/**
 * Register widget area.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
 */
function pixelo_widgets_init() {

    register_sidebar( array(
        'name'          => __( 'Sidebar', 'pixelo' ),
        'id'            => 'sidebar-1',
        'description'   => '',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
    register_sidebar( array(
        'name'          => __( 'Footer 1', 'pixelo' ),
        'id'            => 'footer-1',
        'description'   => '',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
    register_sidebar( array(
        'name'          => __( 'Footer 2', 'pixelo' ),
        'id'            => 'footer-2',
        'description'   => '',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
    register_sidebar( array(
        'name'          => __( 'Footer 3', 'pixelo' ),
        'id'            => 'footer-3',
        'description'   => '',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );

}
add_action( 'widgets_init', 'pixelo_widgets_init' );