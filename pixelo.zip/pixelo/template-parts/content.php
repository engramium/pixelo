<div class="post-header">

	<?php if ( get_the_title() ) : ?>
		<h2 class="post-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
	<?php endif; ?>
    
    <?php if ( is_sticky() ) echo '<span class="sticky-post">' . __( 'Sticky post', 'pixelo' ) . '</span>'; ?>
    
</div><!-- .post-header -->

<?php if ( has_post_thumbnail() ) : ?>

<div class="featured-media">
    <a href="<?php the_permalink(); ?>" rel="bookmark">
        <?php the_post_thumbnail(); ?>
    </a>
</div><!-- .featured-media -->

<?php endif; ?>

<?php if ( get_the_content() ) : ?>
	<div class="post-excerpt">
		<?php the_excerpt( 100 ); ?>
        <a class="read-btn" href="<?php echo esc_url( the_permalink() )?>">Continue Reading <img src="<?php echo esc_url( get_theme_file_uri( '/images/arrow-icon.png' ) )  ?>" alt="Icon"></a>
	</div><!-- .post-excerpt -->
<?php endif; ?>

<div class="post-meta">
    <div class="post-meta">
		
        <a class="post-date" href="<?php the_permalink(); ?>"><?php the_time( get_option( 'date_format' ) ); ?></a>
        
        <?php
        
        if ( function_exists( 'zilla_likes' ) ) zilla_likes(); 
    
        if ( comments_open() ) {
            comments_popup_link( '0', '1', '%', 'post-comments' );
        }
        
        edit_post_link(); 
        
        ?>
        
        <div class="clear"></div>
    
    </div><!-- .post-meta -->
</div>
