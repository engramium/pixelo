<div class="archive-single">
  <div class="post-header">

  <?php if ( get_the_title() ) : ?>
    <h2 class="post-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
  <?php endif; ?>
    
  </div><!-- .post-header -->

  <?php if ( get_the_content() ) : ?>
  <div class="post-excerpt">
    <?php the_excerpt( 100 ); ?>
        <a class="read-btn" href="<?php echo esc_url( the_permalink() )?>">Continue Reading <img src="<?php echo esc_url( get_theme_file_uri( '/images/arrow-icon.png' ) )  ?>" alt="Icon"></a>
  </div><!-- .post-excerpt -->
  <?php endif; ?>

</div>
