<?php
/**
 * The template for displaying archive pages.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package Gazette
 */

get_header(); 

$sidebar_layout = get_theme_mod('pixelo_sidebar_layout_options');

?>


  <div class="archive-page">
    <?php 
        if( $sidebar_layout == 'left-sidebar' ) {
            get_sidebar();
        }

    ?>
    <div class="content-area <?php echo !empty($sidebar_layout) ? esc_attr($sidebar_layout) : ''; ?>">

      <?php
      if ( have_posts() ) : ?>


        <?php while ( have_posts() ) : the_post(); ?>

          <?php
            /* Include the Post-Format-specific template for the content.
            * If you want to override this in a child theme, then include a file
            * called content-___.php (where ___ is the Post Format name) and that will be used instead.
            */
            get_template_part( 'template-parts/content', 'archive' );
          ?>

        <?php endwhile; ?>

      <?php else : ?>

        <?php get_template_part( 'content', 'none' ); ?>

      <?php endif; ?>

    </div><!-- #main -->
      <?php 
        if( $sidebar_layout == 'right-sidebar' ) {
            get_sidebar();
        }
      ?>
  </div><!-- #primary -->

<?php get_footer(); ?>
