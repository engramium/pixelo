<?php get_header(); ?>
<?php if (get_theme_mod('pixelo-basic-author-callout-display') == 'Yes') { ?>
<div class="row row-padding author">
    <div class="col-6 author-image">
    <img loading="lazy" src="<?php echo esc_url( wp_get_attachment_url(get_theme_mod('pixelo-basic-author-callout-image')) ); ?>" alt="<?php echo esc_attr__( "Author Avater", "pixelo" );?>">
    </div>
    <div class="col-6 author-content">
        <?php 
            $authorText = get_theme_mod('pixelo-basic-author-callout-text');
            if ($authorText != '') {
                echo wpautop($authorText);
            } else {
                echo __( "Edit this by going to your Dashboard -> Appearance -> Customise -> Author Editor", "pixelo" );
            }
        ?>
    </div>
</div> 
<?php } ?>
 
<main class="container"> 


<article id="post-<?php the_ID(); ?>" <?php post_class(['blog_wrap row', 'row-padding']); ?>>
<?php
    if(have_posts()) {
        while(have_posts()) : the_post();
?>
    <div class="blog_wrap-item">
        <?php get_template_part( 'template-parts/content', get_post_format() ); ?>
    </div> 
    <?php endwhile; } ?>
</article>


</main>

<?php if ( function_exists( 'paginate_links') !== '' ) { ?>
    <nav class="pagination"><?php echo paginate_links(); ?> </nav> 
    <?php
} else { /*Link to homepage */ } ?>

<?php get_footer(); ?>
