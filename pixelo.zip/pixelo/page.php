<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package Gazette
 */

	get_header(); 
 

?>

	<div class="site-content-inner">
		<div id="primary" class="content-area page__content-wrapper">
            <?php 
                $sidebar_layout = get_post_meta( $post->ID, '_sidebar_meta_kay', true );

                if( $sidebar_layout == 'left-sidebar' ) {
                    get_sidebar();
                }
            ?>
			<main id="main" class="site-main single-page <?php echo !empty($sidebar_layout) ? esc_attr($sidebar_layout) : ''; ?>" role="main">

				<?php while ( have_posts() ) : the_post(); ?>

                    <?php if ( has_post_thumbnail() ) { ?>
                    <div class="hero-image">
                        <?php the_post_thumbnail('large', ['class' => 'objFit'], array('title' => get_the_title() )); ?>
                    </div>
                    <?php } ?>
                    <?php 
                        $site_title = get_post_meta( $post->ID, '_title_meta_kay', true );

                        if( empty( $site_title ) ) {
                            ?>
                                <h1 class="heading"><?php the_title(); ?></h1>
                            <?php
                        }
                    ?>
                    
                    <?php the_content();?>

				<?php endwhile; // end of the loop. ?>

			</main><!-- #main -->
            <?php 
                $sidebar_layout = get_post_meta( $post->ID, '_sidebar_meta_kay', true );

                if( $sidebar_layout == 'right-sidebar' ) {
                    get_sidebar();
                }
            ?>
		</div><!-- #primary -->
        
	</div><!-- .site-content-inner -->

<?php get_footer(); ?>


