<?php 
function pixelo_theme_get_customizer_css() {
	$custom_background_color 		= get_theme_mod( 'custom_background_color', '' );
	$wrapper_background_color 	= get_theme_mod( 'wrapper_background_color', '' );

	$text_color 				= get_theme_mod( 'text_color', '' );
	$link_color 				= get_theme_mod( 'link_color', '' );
	$link_hover_color 	= get_theme_mod( 'link_hover_color', '' );
	$heading_color 			= get_theme_mod( 'heading_color', '' );

?>
<style>
	<?php 
	if ( !empty( $custom_background_color ) ) : ?>
	body { background-color: <?php echo $custom_background_color; ?>; }
	<?php
	endif;

	if ( !empty( $wrapper_background_color ) ) : ?>
	.wrapper { background-color: <?php echo $wrapper_background_color; ?>;}
	<?php 
	endif; 

	if( !empty( $heading_color ) ) : ?>
		h1.heading { 
			color: <?php echo $heading_color; ?>;
		}
	<?php 
	endif;

	if( !empty( $text_color ) ) : ?>
		.site-content p, .content-area p { 
			color: <?php echo $text_color; ?>;
		}
	<?php 
	endif;

	if( !empty( $link_color ) ) : ?>
		.site-content a, .content-area a, .blog_wrap-item a{ 
			color: <?php echo $link_color; ?> !important;
		}
	<?php 
	endif;

	if( !empty( $link_hover_color ) ) : ?>
		.site-content a:hover, .content-area a:hover, .blog_wrap-item a:hover{ 
			color: <?php echo $link_hover_color; ?> !important;
		}
	<?php endif; ?>

</style>

<?php
}
add_action( 'wp_head', 'pixelo_theme_get_customizer_css' );
?>