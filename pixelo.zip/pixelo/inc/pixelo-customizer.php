<?php

class Pixelo_Customizer {

	public function __construct() {
		add_action( 'customize_register', array( $this, 'register_customize_sections' ) );
	}

	public function register_customize_sections( $wp_customize ) {

        /*
        * Add settings to sections.
        */
        $this->colours_callout_section( $wp_customize );
        $this->pixelo_layout_option( $wp_customize );
        $this->pixelo_sidebar_layout_option( $wp_customize );
    }
    
    /* Sanitize Inputs */
    public function sanitize_hex_color( $color ) {
        if ( '' === $color ) {
            return '';
        }
     
        // 3 or 6 hex digits, or the empty string.
        if ( preg_match( '|^#([A-Fa-f0-9]{3}){1,2}$|', $color ) ) {
            return $color;
        }
    }

    public function sanitize_layout_option($input) {
        return ( $input === "boxed" ) ? "boxed" : "full-width";
    }

    public function sanitize_sidebar_option($input) {
        return ( $input === "right-sidebar" ) ? "right-sidebar" : (( $input === 'left-sidebar' ) ? "left-sidebar" : "no-sidebar");
    }

    /* Colours */
    private function colours_callout_section( $wp_customize ) {

        // Background color
        $wp_customize->add_setting( 'custom_background_color', array(
            'default'   => '',
            'transport' => 'refresh',
            'sanitize_callback' => array( $this, 'sanitize_hex_color' )
        ));

        $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'custom_background_color', array(
            'section' => 'colors',
            'label'   => esc_html__( 'Background color', 'pixelo' ),
        )));

        // Text color
        $wp_customize->add_setting( 'text_color', array(
            'default'   => '',
            'transport' => 'refresh',
            'sanitize_callback' => array( $this, 'sanitize_hex_color' )
        ));

        $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'text_color', array(
            'section' => 'colors',
            'label'   => esc_html__( 'Text color', 'pixelo' ),
        )));

        // Link color
        $wp_customize->add_setting( 'link_color', array(
            'default'   => '',
            'transport' => 'refresh',
            'sanitize_callback' => array( $this, 'sanitize_hex_color' )
        ));

        $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'link_color', array(
            'section' => 'colors',
            'label'   => esc_html__( 'Link color', 'pixelo' ),
        )));

        // Link hover color
        $wp_customize->add_setting( 'link_hover_color', array(
            'default'   => '',
            'transport' => 'refresh',
            'sanitize_callback' => array( $this, 'sanitize_hex_color' )
        ));

        $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'link_hover_color', array(
            'section' => 'colors',
            'label'   => esc_html__( 'Link hover color', 'pixelo' ),
        )));

        // Heading color
        $wp_customize->add_setting( 'heading_color', array(
            'default'   => '',
            'transport' => 'refresh',
            'sanitize_callback' => array( $this, 'sanitize_hex_color' )
        ));

        $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'heading_color', array(
            'section' => 'colors',
            'label'   => esc_html__( 'Heading color', 'pixelo' ),
        )));

        
    }

    private function pixelo_layout_option( $wp_customize ) {
        $wp_customize->add_section('pixelo_layout_settings', array(
            'title' => esc_html__('Container', 'pixelo'),
            'priority' => 4,
        ));

        $wp_customize->add_setting( 'pixelo_layout_options', array(
            'default'   => 'boxed',
            'transport' => 'refresh',
            'sanitize_callback' => array( $this, 'sanitize_layout_option' )
        ) );

        $wp_customize->add_control( 'pixelo_layout_options', array(
            'label'     => esc_html__('Layout', 'pixelo'),
            'section'   => 'pixelo_layout_settings',
            'type'      => 'select',
            'choices'   => array(
                'full-width'    => esc_html__( 'Full width', 'pixelo' ),
                'boxed'         => esc_html__( 'Boxed', 'pixelo' ),
            )
        ) );
    }

    /* Sidebar */
    private function pixelo_sidebar_layout_option( $wp_customize ) {
        $wp_customize->add_section('pixelo_sidebar_layout_settings', array(
            'title' => __('Sidebar', 'pixelo'),
            'priority' => 4,
        ));

        $wp_customize->add_setting( 'pixelo_sidebar_layout_options', array(
            'default'   => 'right-sidebar',
            'transport' => 'refresh',
            'sanitize_callback' => array( $this, 'sanitize_sidebar_option' )
        ) );

        $wp_customize->add_control( 'pixelo_sidebar_layout_options', array(
            'label'     => __('Default Sidebar', 'pixelo'),
            'section'   => 'pixelo_sidebar_layout_settings',
            'type'      => 'select',
            'choices'   => array(
                'no-sidebar'        => __( 'No Sidebar', 'pixelo' ),
                'left-sidebar'      => __( 'Left Sidebar', 'pixelo' ),
                'right-sidebar'     => __( 'Right Sidebar', 'pixelo' ),
            )
        ) );
    }

}