<?php
/* Define the custom box */
 
add_action( 'add_meta_boxes', 'pixelo_metabox' );
add_action( 'save_post', 'save_meta_box' );
 
/* Adds a box to the side column on the Post and Page edit screens */
function pixelo_metabox()
{

  $metabox_name = __( 'Pixelo Settings', 'pixelo' );

  $screens = ['closet'];
  foreach ($screens as $screen) {
    add_meta_box( 
        'pixelo_settings_metabox',
        $metabox_name,
        'custom_sidebar_callback',
        array('page', 'post'),
        'side'
    );
  }

}

function custom_sidebar_callback( $post ) {

  // Add an nonce field so we can check for it later.
  wp_nonce_field( 'pixelo_settings_metabox_nonce', 'pixelo_metabox_nonce' );
 
  $site_sidebar = get_post_meta( $post->ID, '_sidebar_meta_kay', true );
  $content_layout = get_post_meta( $post->ID, '_content_meta_kay', true );
  $site_post_title = get_post_meta( $post->ID, '_title_meta_kay', true );


  /**
   * Sidebar Option
   */
  ?>
    
    <div class="pixelo-site-sidebar-layout-meta-wrap pixelo__base-control-field">
      <p class="post-attributes-label-wrapper" >
        <strong> <?php esc_html_e( 'Sidebar', 'pixelo' ); ?> </strong>
      </p>
      <select name="site-sidebar-layout" id="site-sidebar-layout">
        <option value="default" <?php selected( $site_sidebar, 'default' ); ?> > <?php esc_html_e( 'Customizer Setting', 'pixelo' ); ?></option>
        <option value="left-sidebar" <?php selected( $site_sidebar, 'left-sidebar' ); ?> > <?php esc_html_e( 'Left Sidebar', 'pixelo' ); ?></option>
        <option value="right-sidebar" <?php selected( $site_sidebar, 'right-sidebar' ); ?> > <?php esc_html_e( 'Right Sidebar', 'pixelo' ); ?></option>
        <option value="no-sidebar" <?php selected( $site_sidebar, 'no-sidebar' ); ?> > <?php esc_html_e( 'No Sidebar', 'pixelo' ); ?></option>
      </select>
    </div>

  <?php

  /**
   * Layout Option
   */
  ?>
    
    <div class="pixelo-site-content-layout-meta-wrap pixelo__base-control-field">
				<p class="post-attributes-label-wrapper" >
					<strong> <?php esc_html_e( 'Content Layout', 'pixelo' ); ?> </strong>
				</p>
				<select name="site-content-layout" id="site-content-layout">
					<option value="default" <?php selected( $content_layout, 'default' ); ?> > <?php esc_html_e( 'Customizer Setting', 'pixelo' ); ?></option>
					<option value="boxed" <?php selected( $content_layout, 'boxed' ); ?> > <?php esc_html_e( 'Boxed', 'pixelo' ); ?></option>
					<option value="full-width" <?php selected( $content_layout, 'full-width' ); ?> > <?php esc_html_e( 'Full Width ', 'pixelo' ); ?></option>
				</select>
			</div>

  <?php

   /**
   * Disable Section
   */
  ?>
    <div class="pixelo-disable-section-meta-wrap pixelo__base-control-field">
				<p class="post-attributes-label-wrapper">
					<strong> <?php esc_html_e( 'Disable Sections', 'pixelo' ); ?> </strong>
				</p>
      <div class="site-post-title-option-wrap">
        <label for="site-post-title">
          <input type="checkbox" id="site-post-title" name="site-post-title" value="disabled" <?php checked( $site_post_title, 'disabled' ); ?> />
          <?php esc_html_e( 'Disable Title', 'pixelo' ); ?>
        </label>
      </div>
    </div>
  <?php

}

function save_meta_box( $post_id ) {

  // Bail if we're doing an auto save
  if( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
     
  // if our nonce isn't there, or we can't verify it, bail
  if( !isset( $_POST['pixelo_metabox_nonce'] ) || !wp_verify_nonce( $_POST['pixelo_metabox_nonce'], 'pixelo_settings_metabox_nonce' ) ) return;
   
  // if our current user can't edit this post, bail
  if( !current_user_can( 'edit_post' ) ) return;
 
  // Sanitize the user input.
  $sidebar_meta_kay = sanitize_text_field( $_POST['site-sidebar-layout'] );
  $content_meta_kay = sanitize_text_field( $_POST['site-content-layout'] );
  $title_meta_key = sanitize_text_field( $_POST['site-post-title'] );

  // Update the meta field.
  update_post_meta( $post_id, '_sidebar_meta_kay', $sidebar_meta_kay );
  update_post_meta( $post_id, '_content_meta_kay', $content_meta_kay );
  update_post_meta( $post_id, '_title_meta_kay', $title_meta_key );
    


}