<?php 
get_header(); 

$sidebar_layout = get_theme_mod('pixelo_sidebar_layout_options');

?>


<main class="single__blog-post-wrap">
    <?php 
        if( $sidebar_layout == 'left-sidebar' ) {
            get_sidebar();
        }

    ?>
    <div class="single-page post__content-item <?php echo !empty($sidebar_layout) ? esc_attr($sidebar_layout) : ''; ?>">
        <h1 class="heading"><?php the_title(); ?></h1>
        <p class="meta">
            <?php 
            _e( 'By ', 'pixelo' );
            the_author(); 
            _e( ' in', 'pixelo' );
            ?>
            <?php the_category( ' ' ); ?> &middot;
            <time class="date"><?php the_date( get_option( 'date_format' ) ); ?></time>
        </p>

        <?php the_content();?>

        <?php 
        if(has_tag()) {
        ?><div class="post-tags"><?php the_tags(); ?> </div>
        <?php
        } else { /* Article untagged */ } ?>
        <?php
            $defaults = array(
                'before'           => '<p>' . __( 'Pages:', 'pixelo' ),
                'after'            => '</p>',
                'link_before'      => '',
                'link_after'       => '',
                'next_or_number'   => 'number',
                'separator'        => ' ',
                'nextpagelink'     => __( 'Next page', 'pixelo'),
                'previouspagelink' => __( 'Previous page', 'pixelo' ),
                'pagelink'         => '%',
                'echo'             => 1
            );
            wp_link_pages( $defaults );
        ?>

        <?php comments_template() ?>
    </div>
    <?php 
         if( $sidebar_layout == 'right-sidebar' ) {
            get_sidebar();
        }
    ?>
</main>
<?php get_footer(); ?>
